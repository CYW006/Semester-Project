"""
demo.py

Just a little script to demonstrate how to call the interactive Bayesian optimization (IBO/EGO) code.

"""

from numpy import array, arange, zeros
from matplotlib.pylab import *

from pref_GP import GaussianProcess, PrefGaussianProcess
from kernel import GaussianKernel_iso
from sklearn.metrics.pairwise import rbf_kernel
#from ego.acquisition import EI, UCB, maximizeEI, maximizeUCB
#from ego.acquisition.prefutil import query2prefs
#from ego.acquisition.gallery import fastUCBGallery
#from ego.utils.testfunctions import Hartman6


def demoPrefGallery():
    """
    A simpler demo, showing how to use a preference gallery.  This demo
    is not interactive -- assume potential function has optimal point x = 2,y = 1
    """
    
    kernel = GaussianKernel_iso
    
    # set up a Preference Gaussian Process, in which the observations are
    # preferences, rather than scalars
    # assume left is prefered
    left = array([[2.5, 0.5], [2.5, 2]])
    right = array([[2.5, 2], [0, 2]])
    pref = zeros((2,left.shape[0],left.shape[1]))
    pref[0,:,:] = left
    pref[1,:,:] = right
    GP = PrefGaussianProcess(kernel([1]),prefs = pref)
    p_bounds = array([[0, 5], [0, 4]])
    
    for i in range(0,10):
        new_x = GP.find_newpoint(p_bounds)
        
        #only need to modify build_preference
        pref = GP.build_preference(new_x.reshape((1,-1)))
        print(pref)
        #no preference
        if (pref.size == 0):
            break
        GP.addPreferences(pref)
    
    #show preference
    prefs = GP.preferences
    for i in range(0,prefs.shape[1]):
        left = prefs[0,i,:]
        right = prefs[1,i,:]
        print ('%s preferred to %s' % (left, right))
    print(GP.X[np.argmax(GP.Y)])
        
    

if __name__ == '__main__':
    demoPrefGallery()

