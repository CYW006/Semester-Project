#from pref_gp import PrefGaussianProcess
import numpy as np
from numpy import dot
import scipy as sci
import math
from scipy.stats import multivariate_normal
from scipy.optimize import fmin_bfgs
from sklearn.metrics.pairwise import rbf_kernel

def kernel(x, y, kernelscale = 1):
#    length = x.shape[0]
#    width = y.shape[0]
#    cov_matrix = np.zeros((length, width))
#    for i in range(0,length):
#        for j in range(0,width):
#            cov_matrix[i,j] = np.exp(-np.dot((x[i,:] -y[j,:]),(x[i,:] -y[j,:]).T)/(2*kernelscale**2)) #RBF kernel  
#    return cov_matrix
    return rbf_kernel(x,y, 1/kernelscale)

class GaussianProcess(object):
    def __init__(self, X=None, Y=None, pref=None, kernelscale = 1, noise=0.01, low_bound=0.01, up_bound = 4):
        """
        Initialize a Gaussian Process.
        
        @param kernel:       kernel object to use
        @param prior:        object defining the GP prior on the mean.  must 
                             be a descendant of GPMeanPrior
        @param noise:        noise hyperparameter sigma^2_n
        @param X:            initial training data
        @param Y:            initial observations
        @param pref          initial preference
        """

        self.kernelscale = kernelscale  #gaussian kernel
        self.X = X      #samples
        self.Y = Y
        self.low_bound = low_bound  #parameter range
        self.up_bound = up_bound
        self.K = self. calculate_K() #prior covariance
        self.noise = noise
        self.pref_index = np.zeros(((pref.shape[0]),2), dtype = int)
        for i in range(0, pref.shape[0]):
            self.pref_index[i,0] = np.where(self.X == pref[i,0])[0]     #index of preference sample
            self.pref_index[i,1] = np.where(self.X == pref[i,1])[0]
        self.compute_MAP()


        
    def calculate_K(self): 
        return kernel(self.X, self.X, self.kernelscale)    
        
    def calculate_diffloglh(self, f): #calculate first and secpnd derivative of loglikelihood
        compNum = self.pref_index.shape[0]
        samples = self.X.shape[0]
        
        W = np.zeros((samples,samples))
        diff_loglh = np.zeros((samples,1)) 
        
        for i in range(0, compNum):
            s1 = self.pref_index[i,0]
            s2 = self.pref_index[i,1]
            comvar = (f[s1] - f[s2])/(np.sqrt(2)*self.noise)
            cdf = sci.stats.norm.cdf(comvar)
            pdf =sci.stats.norm.pdf(comvar)
            if cdf < 1e-10:
                cdf = 1e-10
            if pdf < 1e-10:
                pdf = 1e-10
            
            temp1 = pdf/cdf/(np.sqrt(2)*self.noise)
            diff_loglh[s1] += temp1
            diff_loglh[s2] -= temp1
            
            temp2 = 0.5/(self.noise**2)*(pdf/cdf)*(pdf/cdf + comvar)
            W[s1,s1] += temp2
            W[s2,s2] += temp2
            W[s1,s2] -= temp2
            W[s2,s1] = W[s1,s2]
        return W, diff_loglh
    
    def evaluate_fmap(self, f):
        S = 0
        for i in range(0, self.pref_index.shape[0]):
            s1 = self.pref_index[i,0]
            s2 = self.pref_index[i,1]
            comvar = (f[s1] - f[s2])/(np.sqrt(2)*self.noise)
            cdf = sci.stats.norm.cdf(comvar)
            if cdf < 1e-10:
                cdf = 1e-10
            S -= np.log(cdf)
        S = S + 0.5*dot(dot(f.T,np.linalg.inv(self.K)),f)
        return S
    
    def compute_MAP(self): 
        samples = self.X.shape[0]
#        err = math.inf
#        K = self.K
#        I = np.eye(samples)
        know_max = np.max(self.Y)  #use known Y as initialization bound
        know_min = np.min(self.Y)
        
        def target_func(f):
            S = 0
            for i in range(0, self.pref_index.shape[0]):
                s1 = self.pref_index[i,0]
                s2 = self.pref_index[i,1]
                comvar = (f[s1] - f[s2])/(np.sqrt(2)*self.noise)
                cdf = sci.stats.norm.cdf(comvar)
                if cdf < 1e-10:
                    cdf = 1e-10
                S -= np.log(cdf)
            return 0.5*dot(f.T,np.linalg.solve(self.K,f)) + S
        
        init_f = np.zeros((samples,1))
        for j in range(0, samples):
            init_f[j] = np.random.uniform(know_min, know_max)  #initialization
        self.fmap = sci.optimize.minimize(lambda f: target_func(f), x0 = init_f).x.reshape(-1,1) #miminization
        return
    '''    
        iteration = 5
        fmap = np.empty((samples,iteration))
        evaluation = np.empty((iteration,1))
        for i in range(0,iteration):   #number of iteration, escape local minimum
            f_old = np.zeros((samples,1))
            for j in range(0, samples):
                f_old[j] = np.random.uniform(know_min, know_max)  #initialization
            while (err>1e-5):
                W,diff_loglh = self.calculate_diffloglh(f_old)
                S = K - dot(dot(K,np.linalg.pinv(I + dot(W,K))),dot(W,K))  #simplification (K(-1) + W)-1
                f_new = dot(S,dot(W,f_old) + diff_loglh)
                err = np.linalg.norm(f_new - f_old, np.inf)
                f_old = f_new
            fmap[:,i] = f_new.ravel()
            evaluation[i] = self.evaluate_fmap(f_new)
        self.fmap = fmap[:,np.argmin(evaluation)]
    '''
    
    def find_newpoint(self):
        def mu(x):
            return dot(kernel(self.X,np.atleast_2d(x)).T,np.linalg.solve(self.K,self.fmap))
        
        def sigma(x):
            W, _ = self.calculate_diffloglh(self.fmap)
            I = np.eye(self.X.shape[0])
            S = self.K - dot(dot(self.K,np.linalg.inv(I + dot(W,self.K))),dot(W,self.K))  #simplification (K(-1) + W)-1
            return kernel(np.atleast_2d(x), np.atleast_2d(x)) - dot(dot(kernel(self.X,np.atleast_2d(x)).T,S),kernel(self.X,np.atleast_2d(x)))
        
        def target_func(x):
            np.atleast_2d(x)
            fmax = np.max(self.Y)
            if (sigma(x) == 0):
                return 0
            return -(mu(x) - fmax)*sci.stats.norm.cdf((mu(x) - fmax)/sigma(x)) - sigma(x)*sci.stats.norm.pdf((mu(x) - fmax)/sigma(x))
            
        x_new = sci.optimize.minimize(lambda x: target_func(x), x0 = np.random.uniform(min(self.Y),max(self.Y)),
                                  bounds=((self.low_bound,self.up_bound),))
        return x_new.x
    
    def add_preference_sample(self, x_new):
        #new observation
        y_new = -(x_new - 2)**2# + np.random.uniform(0, self.noise)
        pref_index = np.empty((self.pref_index.shape[0]+1, self.pref_index.shape[1]))
        
        #further development: user reaction
        if (y_new > np.max(self.Y)):
            pref_index = np.concatenate((self.pref_index, [[len(self.Y), np.argmax(self.Y)]]), axis=0)    #left index is prefered
            self.pref_index = pref_index
        else:
            pref_index = np.concatenate((self.pref_index, [[np.argmax(self.Y), len(self.Y)]]), axis=0)
            self.pref_index = pref_index
        
        self.X = np.concatenate((self.X,np.atleast_2d(x_new)), axis=0)
        self.Y = np.concatenate((self.Y,np.atleast_2d(y_new)), axis=0)
        self.K = self.calculate_K()
        return


    def test(self):
#        print(np.where(self.X == self.preference[1,0])[0])
        return self.pref_index

#Y = -(X-2)^2
init_X = np.array([0,1,2.5,3.5,5]).reshape(5,1)
init_Y = np.array([-4,-1,-0.25,-2.25,-9]).reshape(5,1)
preference = np.array([[1,0],[2.5,1]]) #left preference

GP = GaussianProcess(kernelscale = 1,X = init_X,Y = init_Y, pref = preference)

for i in range(0,20):
    x_new = GP.find_newpoint()
    GP.add_preference_sample(x_new)
    GP.compute_MAP()
    print(x_new)
    print(GP.fmap)

    










